using CelesteStudio.RichText;

namespace CelesteStudio {
	partial class Studio {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Studio));
            this.hotkeyToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.openFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openPreviousFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openRecentMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.integrateReadFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoRemoveExclusiveActionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alwaysOnTopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enabledAutoBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupFileCountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.themesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openSettingsFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acceptSpecialInputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toggleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiltToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.holdButtonsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mashConfigToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.writeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.unlockToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.defineMacroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.insertLoadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveLoadDocToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.openLoadDocToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.enforceLegalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.indexModeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toggleHitboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disableHitboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicHitboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advancedHitboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputDisplayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disableInputDisplayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableInputDisplayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.celesteStudioGithubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dividerLabel = new System.Windows.Forms.Label();
            this.tasTextContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tiltToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.writeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeValue8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeValue16ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeValue32ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeValueFloatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeValueStringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeUnlockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadDocToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertLoadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveLoadDocToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openLoadDocToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertOtherCommandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enforceLegalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteObjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.commentUncommentTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.swapSelectedLAndRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.combineConsecutiveSameInputsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forceCombineInputsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richText = new CelesteStudio.RichText.RichText();
            this.fontDialog = new System.Windows.Forms.FontDialog();
            this.menuStrip.SuspendLayout();
            this.tasTextContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // hotkeyToolTip
            // 
            this.hotkeyToolTip.AutomaticDelay = 200;
            this.hotkeyToolTip.AutoPopDelay = 5000;
            this.hotkeyToolTip.InitialDelay = 200;
            this.hotkeyToolTip.IsBalloon = true;
            this.hotkeyToolTip.ReshowDelay = 200;
            this.hotkeyToolTip.ShowAlways = true;
            this.hotkeyToolTip.ToolTipTitle = "Fact: Birds are hard to catch";
            this.hotkeyToolTip.Popup += new System.Windows.Forms.PopupEventHandler(this.hotkeyToolTip_Popup);
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.toggleToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(286, 24);
            this.menuStrip.TabIndex = 3;
            this.menuStrip.Text = "menuStrip1";
            this.menuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFileToolStripMenuItem,
            this.toolStripSeparator7,
            this.openFileMenuItem,
            this.openPreviousFileToolStripMenuItem,
            this.openRecentMenuItem,
            this.openBackupToolStripMenuItem,
            this.toolStripSeparator15,
            this.saveAsToolStripMenuItem,
            this.integrateReadFilesToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.fileToolStripMenuItem.Text = "&File";
            this.fileToolStripMenuItem.DropDownOpened += new System.EventHandler(this.fileToolStripMenuItem_DropDownOpened);
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // newFileToolStripMenuItem
            // 
            this.newFileToolStripMenuItem.Name = "newFileToolStripMenuItem";
            this.newFileToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.newFileToolStripMenuItem.Text = "&New File";
            this.newFileToolStripMenuItem.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(286, 6);
            // 
            // openFileMenuItem
            // 
            this.openFileMenuItem.Name = "openFileMenuItem";
            this.openFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openFileMenuItem.Size = new System.Drawing.Size(289, 22);
            this.openFileMenuItem.Text = "&Open File...";
            this.openFileMenuItem.Click += new System.EventHandler(this.openFileMenuItem_Click);
            // 
            // openPreviousFileToolStripMenuItem
            // 
            this.openPreviousFileToolStripMenuItem.Name = "openPreviousFileToolStripMenuItem";
            this.openPreviousFileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Left)));
            this.openPreviousFileToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.openPreviousFileToolStripMenuItem.Text = "Open &Previous File";
            this.openPreviousFileToolStripMenuItem.Click += new System.EventHandler(this.openPreviousFileToolStripMenuItem_Click);
            // 
            // openRecentMenuItem
            // 
            this.openRecentMenuItem.Name = "openRecentMenuItem";
            this.openRecentMenuItem.Size = new System.Drawing.Size(289, 22);
            this.openRecentMenuItem.Text = "Open &Recent";
            // 
            // openBackupToolStripMenuItem
            // 
            this.openBackupToolStripMenuItem.Name = "openBackupToolStripMenuItem";
            this.openBackupToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.openBackupToolStripMenuItem.Text = "Open &Backup";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(286, 6);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.saveAsToolStripMenuItem.Text = "&Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // integrateReadFilesToolStripMenuItem
            // 
            this.integrateReadFilesToolStripMenuItem.Name = "integrateReadFilesToolStripMenuItem";
            this.integrateReadFilesToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.integrateReadFilesToolStripMenuItem.Text = "&Integrate Read Files...";
            this.integrateReadFilesToolStripMenuItem.Click += new System.EventHandler(this.integrateReadFilesToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.autoRemoveExclusiveActionsToolStripMenuItem,
            this.acceptSpecialInputToolStripMenuItem,
            this.alwaysOnTopToolStripMenuItem,
            this.autoBackupToolStripMenuItem,
            this.fontToolStripMenuItem,
            this.themesToolStripMenuItem,
            this.openSettingsFileToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.settingsToolStripMenuItem.Text = "&Settings";
            this.settingsToolStripMenuItem.DropDownOpened += new System.EventHandler(this.settingsToolStripMenuItem_Opened);
            // 
            // autoRemoveExclusiveActionsToolStripMenuItem
            // 
            this.autoRemoveExclusiveActionsToolStripMenuItem.Name = "autoRemoveExclusiveActionsToolStripMenuItem";
            this.autoRemoveExclusiveActionsToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.autoRemoveExclusiveActionsToolStripMenuItem.Text = "Auto Remove Mutually Exclusive Actions";
            this.autoRemoveExclusiveActionsToolStripMenuItem.Click += new System.EventHandler(this.autoRemoveExclusiveActionsToolStripMenuItem_Click);
            // 
            // alwaysOnTopToolStripMenuItem
            // 
            this.alwaysOnTopToolStripMenuItem.Name = "alwaysOnTopToolStripMenuItem";
            this.alwaysOnTopToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.alwaysOnTopToolStripMenuItem.Text = "Always on Top";
            this.alwaysOnTopToolStripMenuItem.Click += new System.EventHandler(this.alwaysOnTopToolStripMenuItem_Click);
            // 
            // autoBackupToolStripMenuItem
            // 
            this.autoBackupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enabledAutoBackupToolStripMenuItem,
            this.backupRateToolStripMenuItem,
            this.backupFileCountsToolStripMenuItem});
            this.autoBackupToolStripMenuItem.Name = "autoBackupToolStripMenuItem";
            this.autoBackupToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.autoBackupToolStripMenuItem.Text = "Automatic Backup";
            // 
            // enabledAutoBackupToolStripMenuItem
            // 
            this.enabledAutoBackupToolStripMenuItem.Checked = true;
            this.enabledAutoBackupToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enabledAutoBackupToolStripMenuItem.Name = "enabledAutoBackupToolStripMenuItem";
            this.enabledAutoBackupToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.enabledAutoBackupToolStripMenuItem.Text = "Enabled";
            this.enabledAutoBackupToolStripMenuItem.Click += new System.EventHandler(this.enabledAutoBackupToolStripMenuItem_Click);
            // 
            // backupRateToolStripMenuItem
            // 
            this.backupRateToolStripMenuItem.Name = "backupRateToolStripMenuItem";
            this.backupRateToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.backupRateToolStripMenuItem.Text = "Backup Rate (minutes)";
            this.backupRateToolStripMenuItem.ToolTipText = "0 means the file will be backed up every time it is modified";
            this.backupRateToolStripMenuItem.Click += new System.EventHandler(this.backupRateToolStripMenuItem_Click);
            // 
            // backupFileCountsToolStripMenuItem
            // 
            this.backupFileCountsToolStripMenuItem.Name = "backupFileCountsToolStripMenuItem";
            this.backupFileCountsToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.backupFileCountsToolStripMenuItem.Text = "Backup File Count";
            this.backupFileCountsToolStripMenuItem.ToolTipText = "0 means no limit";
            this.backupFileCountsToolStripMenuItem.Click += new System.EventHandler(this.backupFileCountsToolStripMenuItem_Click);
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.fontToolStripMenuItem.Text = "Font...";
            this.fontToolStripMenuItem.Click += new System.EventHandler(this.fontToolStripMenuItem_Click);
            // 
            // themesToolStripMenuItem
            // 
            this.themesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lightToolStripMenuItem,
            this.darkToolStripMenuItem,
            this.customToolStripMenuItem});
            this.themesToolStripMenuItem.Name = "themesToolStripMenuItem";
            this.themesToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.themesToolStripMenuItem.Text = "Themes";
            this.themesToolStripMenuItem.DropDownOpened += new System.EventHandler(this.themesToolStripMenuItem_DropDownOpened);
            // 
            // lightToolStripMenuItem
            // 
            this.lightToolStripMenuItem.Name = "lightToolStripMenuItem";
            this.lightToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.lightToolStripMenuItem.Text = "Light";
            this.lightToolStripMenuItem.Click += new System.EventHandler(this.lightToolStripMenuItem_Click);
            // 
            // darkToolStripMenuItem
            // 
            this.darkToolStripMenuItem.Name = "darkToolStripMenuItem";
            this.darkToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.darkToolStripMenuItem.Text = "Dark";
            this.darkToolStripMenuItem.Click += new System.EventHandler(this.darkToolStripMenuItem_Click);
            // 
            // customToolStripMenuItem
            // 
            this.customToolStripMenuItem.Name = "customToolStripMenuItem";
            this.customToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.customToolStripMenuItem.Text = "Custom";
            this.customToolStripMenuItem.Click += new System.EventHandler(this.customToolStripMenuItem_Click);
            // 
            // openSettingsFileToolStripMenuItem
            // 
            this.openSettingsFileToolStripMenuItem.Name = "openSettingsFileToolStripMenuItem";
            this.openSettingsFileToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.openSettingsFileToolStripMenuItem.Text = "Open Settings File...";
            this.openSettingsFileToolStripMenuItem.Click += new System.EventHandler(this.openSettingsFileToolStripMenuItem_Click);
            // 
            // acceptSpecialInputToolStripMenuItem
            // 
            this.acceptSpecialInputToolStripMenuItem.Name = "acceptSpecialInputToolStripMenuItem";
            this.acceptSpecialInputToolStripMenuItem.Size = new System.Drawing.Size(378, 22);
            this.acceptSpecialInputToolStripMenuItem.Text = "Accept  [ ] =  as input";
            this.acceptSpecialInputToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toggleToolStripMenuItem
            // 
            this.toggleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiltToolStripMenuItem1,
            this.holdButtonsToolStripMenuItem,
            this.mashConfigToolStripMenuItem1,
            this.readToolStripMenuItem1,
            this.writeToolStripMenuItem1,
            this.unlockToolStripMenuItem1,
            this.defineMacroToolStripMenuItem,
            this.toolStripMenuItem11,
            this.toolStripMenuItem15,
            this.toolStripSeparator1,
            this.toggleHitboxesToolStripMenuItem,
            this.inputDisplayToolStripMenuItem});
            this.toggleToolStripMenuItem.Name = "toggleToolStripMenuItem";
            this.toggleToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.toggleToolStripMenuItem.Text = "&Commands";
            this.toggleToolStripMenuItem.Click += new System.EventHandler(this.toggleToolStripMenuItem_Click);
            // 
            // tiltToolStripMenuItem1
            // 
            this.tiltToolStripMenuItem1.Name = "tiltToolStripMenuItem1";
            this.tiltToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tiltToolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.tiltToolStripMenuItem1.Text = "Tilt";
            this.tiltToolStripMenuItem1.ToolTipText = "Set the controller\'s tilt (0-1023)";
            this.tiltToolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // holdButtonsToolStripMenuItem
            // 
            this.holdButtonsToolStripMenuItem.Name = "holdButtonsToolStripMenuItem";
            this.holdButtonsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.holdButtonsToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.holdButtonsToolStripMenuItem.Text = "Hold Buttons";
            this.holdButtonsToolStripMenuItem.ToolTipText = "Hold the specified buttons. To release, use the command with no arguments.";
            this.holdButtonsToolStripMenuItem.Click += new System.EventHandler(this.holdButtonsToolStripMenuItem_Click);
            // 
            // mashConfigToolStripMenuItem1
            // 
            this.mashConfigToolStripMenuItem1.Name = "mashConfigToolStripMenuItem1";
            this.mashConfigToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.mashConfigToolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.mashConfigToolStripMenuItem1.Text = "Repeat";
            this.mashConfigToolStripMenuItem1.ToolTipText = "Repeat, n\r\n-input-\r\nEndRepeat\r\n\r\nRepeats enclosed lines n times";
            this.mashConfigToolStripMenuItem1.Click += new System.EventHandler(this.mashConfigToolStripMenuItem1_Click);
            // 
            // readToolStripMenuItem1
            // 
            this.readToolStripMenuItem1.Name = "readToolStripMenuItem1";
            this.readToolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.readToolStripMenuItem1.Text = "Read";
            this.readToolStripMenuItem1.ToolTipText = "Will read inputs from the specified file.";
            this.readToolStripMenuItem1.Click += new System.EventHandler(this.readToolStripMenuItem1_Click);
            // 
            // writeToolStripMenuItem1
            // 
            this.writeToolStripMenuItem1.Name = "writeToolStripMenuItem1";
            this.writeToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this.writeToolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.writeToolStripMenuItem1.Text = "Write";
            this.writeToolStripMenuItem1.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeToolStripMenuItem1.Click += new System.EventHandler(this.writeToolStripMenuItem1_Click);
            // 
            // unlockToolStripMenuItem1
            // 
            this.unlockToolStripMenuItem1.Name = "unlockToolStripMenuItem1";
            this.unlockToolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.unlockToolStripMenuItem1.Text = "Unlock";
            this.unlockToolStripMenuItem1.ToolTipText = "Clears the Locked Value Write list";
            this.unlockToolStripMenuItem1.Click += new System.EventHandler(this.unlockToolStripMenuItem1_Click);
            // 
            // defineMacroToolStripMenuItem
            // 
            this.defineMacroToolStripMenuItem.Name = "defineMacroToolStripMenuItem";
            this.defineMacroToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.defineMacroToolStripMenuItem.Text = "Define Macro";
            this.defineMacroToolStripMenuItem.ToolTipText = "Create an input macro that can be called later in the TAS file\r\n\r\nExample TAS:\r\nM" +
    "acro, crouch\r\n   1,D\r\n   1\r\nEndMacro\r\n\r\n#Start\r\n31\r\ncrouch, 15";
            this.defineMacroToolStripMenuItem.Click += new System.EventHandler(this.defineMacroToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertLoadToolStripMenuItem1,
            this.saveLoadDocToolStripMenuItem1,
            this.openLoadDocToolStripMenuItem1});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(234, 22);
            this.toolStripMenuItem11.Text = "Load Management";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // insertLoadToolStripMenuItem1
            // 
            this.insertLoadToolStripMenuItem1.Name = "insertLoadToolStripMenuItem1";
            this.insertLoadToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.insertLoadToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.insertLoadToolStripMenuItem1.Text = "Insert Load";
            this.insertLoadToolStripMenuItem1.ToolTipText = "Pause inputs until the next load ends. Each load must be given a unique ID in ord" +
    "er to be documented by the script.";
            this.insertLoadToolStripMenuItem1.Click += new System.EventHandler(this.insertLoadToolStripMenuItem1_Click);
            // 
            // saveLoadDocToolStripMenuItem1
            // 
            this.saveLoadDocToolStripMenuItem1.Name = "saveLoadDocToolStripMenuItem1";
            this.saveLoadDocToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.saveLoadDocToolStripMenuItem1.Text = "Save LoadDoc";
            this.saveLoadDocToolStripMenuItem1.ToolTipText = "Exports Load Documentation to a file\r\nUseful to keep data between sessions";
            this.saveLoadDocToolStripMenuItem1.Click += new System.EventHandler(this.saveLoadDocToolStripMenuItem1_Click);
            // 
            // openLoadDocToolStripMenuItem1
            // 
            this.openLoadDocToolStripMenuItem1.Name = "openLoadDocToolStripMenuItem1";
            this.openLoadDocToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.openLoadDocToolStripMenuItem1.Text = "Open LoadDoc";
            this.openLoadDocToolStripMenuItem1.ToolTipText = "Opens a previously saved Load Document. Should be placed at the start of the file" +
    ".";
            this.openLoadDocToolStripMenuItem1.Click += new System.EventHandler(this.openLoadDocToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enforceLegalToolStripMenuItem1,
            this.indexModeToolStripMenuItem1,
            this.deleteToolStripMenuItem1});
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(234, 22);
            this.toolStripMenuItem15.Text = "Insert Other Command";
            // 
            // enforceLegalToolStripMenuItem1
            // 
            this.enforceLegalToolStripMenuItem1.Name = "enforceLegalToolStripMenuItem1";
            this.enforceLegalToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.enforceLegalToolStripMenuItem1.Text = "EnforceLegal";
            this.enforceLegalToolStripMenuItem1.ToolTipText = "This is used at the start of fullgame files.\r\nIt prevents the use of commands whi" +
    "ch would not be legal in a run.";
            this.enforceLegalToolStripMenuItem1.Click += new System.EventHandler(this.enforceLegalToolStripMenuItem1_Click);
            // 
            // indexModeToolStripMenuItem1
            // 
            this.indexModeToolStripMenuItem1.Name = "indexModeToolStripMenuItem1";
            this.indexModeToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.indexModeToolStripMenuItem1.Text = "Manual Indexing";
            this.indexModeToolStripMenuItem1.ToolTipText = "Set the TAS frame offset manually";
            this.indexModeToolStripMenuItem1.Click += new System.EventHandler(this.indexModeToolStripMenuItem1_Click);
            // 
            // deleteToolStripMenuItem1
            // 
            this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            this.deleteToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.deleteToolStripMenuItem1.Text = "Delete Object";
            this.deleteToolStripMenuItem1.ToolTipText = "Delete, Address\r\nDeletes the object at the provided address";
            this.deleteToolStripMenuItem1.Click += new System.EventHandler(this.deleteToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(231, 6);
            // 
            // toggleHitboxesToolStripMenuItem
            // 
            this.toggleHitboxesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.disableHitboxesToolStripMenuItem,
            this.basicHitboxesToolStripMenuItem,
            this.advancedHitboxesToolStripMenuItem});
            this.toggleHitboxesToolStripMenuItem.Name = "toggleHitboxesToolStripMenuItem";
            this.toggleHitboxesToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.toggleHitboxesToolStripMenuItem.Text = "&Hitboxes";
            this.toggleHitboxesToolStripMenuItem.ToolTipText = "Configure Hitbox Mode, if using a Hitbox Mod.";
            this.toggleHitboxesToolStripMenuItem.Click += new System.EventHandler(this.toggleHitboxesToolStripMenuItem_Click);
            // 
            // disableHitboxesToolStripMenuItem
            // 
            this.disableHitboxesToolStripMenuItem.Name = "disableHitboxesToolStripMenuItem";
            this.disableHitboxesToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.disableHitboxesToolStripMenuItem.Text = "Disable";
            this.disableHitboxesToolStripMenuItem.Click += new System.EventHandler(this.disableToolStripMenuItem_Click);
            // 
            // basicHitboxesToolStripMenuItem
            // 
            this.basicHitboxesToolStripMenuItem.Name = "basicHitboxesToolStripMenuItem";
            this.basicHitboxesToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.basicHitboxesToolStripMenuItem.Text = "Basic";
            this.basicHitboxesToolStripMenuItem.Click += new System.EventHandler(this.basicToolStripMenuItem_Click);
            // 
            // advancedHitboxesToolStripMenuItem
            // 
            this.advancedHitboxesToolStripMenuItem.Name = "advancedHitboxesToolStripMenuItem";
            this.advancedHitboxesToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.advancedHitboxesToolStripMenuItem.Text = "Advanced";
            this.advancedHitboxesToolStripMenuItem.Click += new System.EventHandler(this.advancedToolStripMenuItem_Click);
            // 
            // inputDisplayToolStripMenuItem
            // 
            this.inputDisplayToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.disableInputDisplayToolStripMenuItem,
            this.enableInputDisplayToolStripMenuItem});
            this.inputDisplayToolStripMenuItem.Name = "inputDisplayToolStripMenuItem";
            this.inputDisplayToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.inputDisplayToolStripMenuItem.Text = "Input Display";
            this.inputDisplayToolStripMenuItem.ToolTipText = "Toggle Input Display, if using an Input Display Mod.";
            // 
            // disableInputDisplayToolStripMenuItem
            // 
            this.disableInputDisplayToolStripMenuItem.Name = "disableInputDisplayToolStripMenuItem";
            this.disableInputDisplayToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.disableInputDisplayToolStripMenuItem.Text = "Disable";
            this.disableInputDisplayToolStripMenuItem.Click += new System.EventHandler(this.disableToolStripMenuItem1_Click);
            // 
            // enableInputDisplayToolStripMenuItem
            // 
            this.enableInputDisplayToolStripMenuItem.Name = "enableInputDisplayToolStripMenuItem";
            this.enableInputDisplayToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.enableInputDisplayToolStripMenuItem.Text = "Enable";
            this.enableInputDisplayToolStripMenuItem.Click += new System.EventHandler(this.enableToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeMenuItem,
            this.celesteStudioGithubToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // homeMenuItem
            // 
            this.homeMenuItem.Name = "homeMenuItem";
            this.homeMenuItem.Size = new System.Drawing.Size(242, 22);
            this.homeMenuItem.Text = "&NSMBW Github";
            this.homeMenuItem.Click += new System.EventHandler(this.homeMenuItem_Click);
            // 
            // celesteStudioGithubToolStripMenuItem
            // 
            this.celesteStudioGithubToolStripMenuItem.Name = "celesteStudioGithubToolStripMenuItem";
            this.celesteStudioGithubToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.celesteStudioGithubToolStripMenuItem.Text = "Celeste Studio Github";
            this.celesteStudioGithubToolStripMenuItem.Click += new System.EventHandler(this.celesteStudioGithubToolStripMenuItem_Click);
            // 
            // dividerLabel
            // 
            this.dividerLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.dividerLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.dividerLabel.Location = new System.Drawing.Point(0, 24);
            this.dividerLabel.Name = "dividerLabel";
            this.dividerLabel.Size = new System.Drawing.Size(286, 1);
            this.dividerLabel.TabIndex = 4;
            // 
            // tasTextContextMenuStrip
            // 
            this.tasTextContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiltToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.writeToolStripMenuItem,
            this.readToolStripMenuItem,
            this.toolStripMenuItem4,
            this.loadDocToolStripMenuItem,
            this.insertOtherCommandToolStripMenuItem,
            this.toolStripSeparator4,
            this.commentUncommentTextToolStripMenuItem,
            this.swapSelectedLAndRToolStripMenuItem,
            this.combineConsecutiveSameInputsToolStripMenuItem,
            this.forceCombineInputsToolStripMenuItem});
            this.tasTextContextMenuStrip.Name = "tasTextContextMenuStrip";
            this.tasTextContextMenuStrip.Size = new System.Drawing.Size(305, 296);
            this.tasTextContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.tasTextContextMenuStrip_Opening);
            // 
            // tiltToolStripMenuItem
            // 
            this.tiltToolStripMenuItem.Name = "tiltToolStripMenuItem";
            this.tiltToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tiltToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.tiltToolStripMenuItem.Text = "Tilt";
            this.tiltToolStripMenuItem.ToolTipText = "Set the controller\'s tilt (0-1023)";
            this.tiltToolStripMenuItem.Click += new System.EventHandler(this.tToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.toolStripMenuItem1.Size = new System.Drawing.Size(304, 22);
            this.toolStripMenuItem1.Text = "Hold Buttons";
            this.toolStripMenuItem1.ToolTipText = "Hold the specified buttons. To release, use the command with no arguments.";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click_2);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.toolStripMenuItem2.Size = new System.Drawing.Size(304, 22);
            this.toolStripMenuItem2.Text = "Repeat";
            this.toolStripMenuItem2.ToolTipText = "Repeat, n\r\n-input-\r\nEndRepeat\r\n\r\nRepeats enclosed lines n times";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click_1);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(304, 22);
            this.toolStripMenuItem3.Text = "Read";
            this.toolStripMenuItem3.ToolTipText = "Will read inputs from the specified file.";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // writeToolStripMenuItem
            // 
            this.writeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.writeValue8ToolStripMenuItem,
            this.writeValue16ToolStripMenuItem,
            this.writeValue32ToolStripMenuItem,
            this.writeValueFloatToolStripMenuItem,
            this.writeValueStringToolStripMenuItem,
            this.writeUnlockToolStripMenuItem});
            this.writeToolStripMenuItem.Name = "writeToolStripMenuItem";
            this.writeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this.writeToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.writeToolStripMenuItem.Text = "Write";
            this.writeToolStripMenuItem.Click += new System.EventHandler(this.writeToolStripMenuItem_Click);
            // 
            // writeValue8ToolStripMenuItem
            // 
            this.writeValue8ToolStripMenuItem.Name = "writeValue8ToolStripMenuItem";
            this.writeValue8ToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeValue8ToolStripMenuItem.Text = "8";
            this.writeValue8ToolStripMenuItem.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeValue8ToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // writeValue16ToolStripMenuItem
            // 
            this.writeValue16ToolStripMenuItem.Name = "writeValue16ToolStripMenuItem";
            this.writeValue16ToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeValue16ToolStripMenuItem.Text = "16";
            this.writeValue16ToolStripMenuItem.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeValue16ToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // writeValue32ToolStripMenuItem
            // 
            this.writeValue32ToolStripMenuItem.Name = "writeValue32ToolStripMenuItem";
            this.writeValue32ToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeValue32ToolStripMenuItem.Text = "32";
            this.writeValue32ToolStripMenuItem.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeValue32ToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // writeValueFloatToolStripMenuItem
            // 
            this.writeValueFloatToolStripMenuItem.Name = "writeValueFloatToolStripMenuItem";
            this.writeValueFloatToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeValueFloatToolStripMenuItem.Text = "Float";
            this.writeValueFloatToolStripMenuItem.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeValueFloatToolStripMenuItem.Click += new System.EventHandler(this.floatToolStripMenuItem_Click);
            // 
            // writeValueStringToolStripMenuItem
            // 
            this.writeValueStringToolStripMenuItem.Name = "writeValueStringToolStripMenuItem";
            this.writeValueStringToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeValueStringToolStripMenuItem.Text = "String";
            this.writeValueStringToolStripMenuItem.ToolTipText = "Write, Data Type, Address, Value[, lock]";
            this.writeValueStringToolStripMenuItem.Click += new System.EventHandler(this.stringToolStripMenuItem_Click);
            // 
            // writeUnlockToolStripMenuItem
            // 
            this.writeUnlockToolStripMenuItem.Name = "writeUnlockToolStripMenuItem";
            this.writeUnlockToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.writeUnlockToolStripMenuItem.Text = "Unlock";
            this.writeUnlockToolStripMenuItem.ToolTipText = "Clears the Locked Value list";
            this.writeUnlockToolStripMenuItem.Click += new System.EventHandler(this.unlockToolStripMenuItem_Click);
            // 
            // readToolStripMenuItem
            // 
            this.readToolStripMenuItem.Name = "readToolStripMenuItem";
            this.readToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.readToolStripMenuItem.Text = "Read";
            this.readToolStripMenuItem.ToolTipText = "Will read inputs from the specified file.";
            this.readToolStripMenuItem.Click += new System.EventHandler(this.readToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(304, 22);
            this.toolStripMenuItem4.Text = "Define Macro";
            this.toolStripMenuItem4.ToolTipText = "Create an input macro that can be called later in the TAS file\r\n\r\nExample TAS:\r\nM" +
    "acro, crouch\r\n   1,D\r\n   1\r\nEndMacro\r\n\r\n#Start\r\n31\r\ncrouch, 15";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click_1);
            // 
            // loadDocToolStripMenuItem
            // 
            this.loadDocToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertLoadToolStripMenuItem,
            this.saveLoadDocToolStripMenuItem,
            this.openLoadDocToolStripMenuItem});
            this.loadDocToolStripMenuItem.Name = "loadDocToolStripMenuItem";
            this.loadDocToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.loadDocToolStripMenuItem.Text = "Load Management";
            this.loadDocToolStripMenuItem.Click += new System.EventHandler(this.loadDocToolStripMenuItem_Click);
            // 
            // insertLoadToolStripMenuItem
            // 
            this.insertLoadToolStripMenuItem.Name = "insertLoadToolStripMenuItem";
            this.insertLoadToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.insertLoadToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.insertLoadToolStripMenuItem.Text = "Insert Load";
            this.insertLoadToolStripMenuItem.ToolTipText = "Pause inputs until the next load ends. Each load must be given a unique ID in ord" +
    "er to be documented by the script.";
            this.insertLoadToolStripMenuItem.Click += new System.EventHandler(this.insertLoadToolStripMenuItem_Click);
            // 
            // saveLoadDocToolStripMenuItem
            // 
            this.saveLoadDocToolStripMenuItem.Name = "saveLoadDocToolStripMenuItem";
            this.saveLoadDocToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.saveLoadDocToolStripMenuItem.Text = "Save LoadDoc";
            this.saveLoadDocToolStripMenuItem.ToolTipText = "Exports Load Documentation to a file\r\nUseful to keep data between sessions";
            this.saveLoadDocToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // openLoadDocToolStripMenuItem
            // 
            this.openLoadDocToolStripMenuItem.Name = "openLoadDocToolStripMenuItem";
            this.openLoadDocToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.openLoadDocToolStripMenuItem.Text = "Open LoadDoc";
            this.openLoadDocToolStripMenuItem.ToolTipText = "Opens a previously saved Load Document. Should be placed at the start of the file" +
    ".";
            this.openLoadDocToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // insertOtherCommandToolStripMenuItem
            // 
            this.insertOtherCommandToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enforceLegalToolStripMenuItem,
            this.toolStripMenuItem5,
            this.deleteObjectToolStripMenuItem});
            this.insertOtherCommandToolStripMenuItem.Name = "insertOtherCommandToolStripMenuItem";
            this.insertOtherCommandToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.insertOtherCommandToolStripMenuItem.Text = "Insert Other Command";
            // 
            // enforceLegalToolStripMenuItem
            // 
            this.enforceLegalToolStripMenuItem.Name = "enforceLegalToolStripMenuItem";
            this.enforceLegalToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.enforceLegalToolStripMenuItem.Text = "EnforceLegal";
            this.enforceLegalToolStripMenuItem.ToolTipText = "This is used at the start of fullgame files.\r\nIt prevents the use of commands whi" +
    "ch would not be legal in a run.";
            this.enforceLegalToolStripMenuItem.Click += new System.EventHandler(this.enforceLegalToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem5.Text = "Manual Indexing";
            this.toolStripMenuItem5.ToolTipText = "Set the TAS frame offset manually";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // deleteObjectToolStripMenuItem
            // 
            this.deleteObjectToolStripMenuItem.Name = "deleteObjectToolStripMenuItem";
            this.deleteObjectToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.deleteObjectToolStripMenuItem.Text = "Delete Object";
            this.deleteObjectToolStripMenuItem.ToolTipText = "Delete, Address\r\nDeletes the object at the provided address";
            this.deleteObjectToolStripMenuItem.Click += new System.EventHandler(this.deleteObjectToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(301, 6);
            // 
            // commentUncommentTextToolStripMenuItem
            // 
            this.commentUncommentTextToolStripMenuItem.Name = "commentUncommentTextToolStripMenuItem";
            this.commentUncommentTextToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
            this.commentUncommentTextToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.commentUncommentTextToolStripMenuItem.Text = "Comment/Uncomment Text";
            this.commentUncommentTextToolStripMenuItem.Click += new System.EventHandler(this.commentUncommentTextToolStripMenuItem_Click);
            // 
            // swapSelectedLAndRToolStripMenuItem
            // 
            this.swapSelectedLAndRToolStripMenuItem.Name = "swapSelectedLAndRToolStripMenuItem";
            this.swapSelectedLAndRToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.swapSelectedLAndRToolStripMenuItem.Text = "Swap Selected L and R";
            this.swapSelectedLAndRToolStripMenuItem.Click += new System.EventHandler(this.swapSelectedLAndRToolStripMenuItem_Click);
            // 
            // combineConsecutiveSameInputsToolStripMenuItem
            // 
            this.combineConsecutiveSameInputsToolStripMenuItem.Name = "combineConsecutiveSameInputsToolStripMenuItem";
            this.combineConsecutiveSameInputsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.combineConsecutiveSameInputsToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.combineConsecutiveSameInputsToolStripMenuItem.Text = "Combine Consecutive Same Inputs";
            this.combineConsecutiveSameInputsToolStripMenuItem.Click += new System.EventHandler(this.combineConsecutiveSameInputsToolStripMenuItem_Click);
            // 
            // forceCombineInputsToolStripMenuItem
            // 
            this.forceCombineInputsToolStripMenuItem.Name = "forceCombineInputsToolStripMenuItem";
            this.forceCombineInputsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.L)));
            this.forceCombineInputsToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.forceCombineInputsToolStripMenuItem.Text = "Force Combine Inputs Frames";
            this.forceCombineInputsToolStripMenuItem.Click += new System.EventHandler(this.forceCombineInputsToolStripMenuItem_Click);
            // 
            // richText
            // 
            this.richText.AllowDrop = true;
            this.richText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richText.AutoIndent = false;
            this.richText.AutoScrollMinSize = new System.Drawing.Size(33, 84);
            this.richText.BackBrush = null;
            this.richText.ChangedLineBgColor = System.Drawing.Color.DarkOrange;
            this.richText.ChangedLineTextColor = System.Drawing.Color.Teal;
            this.richText.CommentPrefix = "#";
            this.richText.CurrentFileName = null;
            this.richText.CurrentLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.richText.CurrentLineSuffix = null;
            this.richText.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.richText.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.richText.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richText.ForeColor = System.Drawing.Color.Black;
            this.richText.Language = CelesteStudio.RichText.Language.TAS;
            this.richText.LineNumberColor = System.Drawing.Color.Black;
            this.richText.Location = new System.Drawing.Point(0, 26);
            this.richText.Name = "richText";
            this.richText.Paddings = new System.Windows.Forms.Padding(0);
            this.richText.PlayingLineBgColor = System.Drawing.Color.Lime;
            this.richText.PlayingLineTextColor = System.Drawing.Color.Teal;
            this.richText.SaveStateBgColor = System.Drawing.Color.SteelBlue;
            this.richText.SaveStateLine = -1;
            this.richText.SaveStateTextColor = System.Drawing.Color.White;
            this.richText.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.richText.Size = new System.Drawing.Size(286, 626);
            this.richText.TabIndex = 0;
            this.richText.TabLength = 0;
            this.richText.TextChanged += new System.EventHandler<CelesteStudio.RichText.TextChangedEventArgs>(this.tasText_TextChanged);
            this.richText.NoChanges += new System.EventHandler(this.tasText_NoChanges);
            this.richText.FileOpening += new System.EventHandler(this.tasText_FileOpening);
            this.richText.LineInserted += new System.EventHandler<CelesteStudio.RichText.LineInsertedEventArgs>(this.tasText_LineInserted);
            this.richText.LineNeeded += new System.EventHandler<CelesteStudio.RichText.LineNeededEventArgs>(this.tasText_LineNeeded);
            this.richText.LineRemoved += new System.EventHandler<CelesteStudio.RichText.LineRemovedEventArgs>(this.tasText_LineRemoved);
            this.richText.Load += new System.EventHandler(this.richText_Load);
            // 
            // fontDialog
            // 
            this.fontDialog.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Studio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(286, 652);
            this.Controls.Add(this.dividerLabel);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.richText);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(192, 220);
            this.Name = "Studio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Studio";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TASStudio_FormClosed);
            this.Load += new System.EventHandler(this.Studio_Load);
            this.Shown += new System.EventHandler(this.Studio_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Studio_KeyDown);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.tasTextContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.ToolStripMenuItem openSettingsFileToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem integrateReadFilesToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem swapSelectedLAndRToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem themesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem darkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem combineConsecutiveSameInputsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forceCombineInputsToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem openBackupToolStripMenuItem;

        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;

        private System.Windows.Forms.ToolStripMenuItem backupFileCountsToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem backupRateToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem autoBackupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enabledAutoBackupToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem openPreviousFileToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem toggleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toggleHitboxesToolStripMenuItem;

        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;

        private System.Windows.Forms.ToolStripMenuItem newFileToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem autoRemoveExclusiveActionsToolStripMenuItem;

        #endregion
		public CelesteStudio.RichText.RichText richText;
        private System.Windows.Forms.ToolTip hotkeyToolTip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.Label dividerLabel;
        private System.Windows.Forms.ToolStripMenuItem openFileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openRecentMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeMenuItem;
        private System.Windows.Forms.ContextMenuStrip tasTextContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commentUncommentTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertOtherCommandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enforceLegalToolStripMenuItem;
        private System.Windows.Forms.FontDialog fontDialog;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alwaysOnTopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiltToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem writeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeValue8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeValue16ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeValue32ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeValueFloatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeValueStringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeUnlockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadDocToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveLoadDocToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openLoadDocToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertLoadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteObjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableHitboxesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicHitboxesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advancedHitboxesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputDisplayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableInputDisplayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enableInputDisplayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem celesteStudioGithubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiltToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mashConfigToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem writeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem insertLoadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveLoadDocToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem openLoadDocToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem enforceLegalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem indexModeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem unlockToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem holdButtonsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem defineMacroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem acceptSpecialInputToolStripMenuItem;
    }
}