using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace StudioCommunication;

[Flags]
public enum Actions {
    None = 0,
    Left = 1 << 0,
    Right = 1 << 1,
    Up = 1 << 2,
    Down = 1 << 3,
    Jump = 1 << 4,
    Jump2 = 1 << 5,
    Spinput = 1 << 6,
    NoRun = 1 << 7,
    BAction = 1 << 8,
    BAction2 = 1 << 9,
    Minus = 1 << 10,
    Plus = 1 << 11,
    Home = 1 << 12,
    NunchuckC = 1 << 13
}

public static class ActionsUtils {
    public static readonly ReadOnlyDictionary<char, Actions> Chars = new(
        new Dictionary<char, Actions> {
            {'L', Actions.Left},
            {'R', Actions.Right},  
            {'U', Actions.Up},
            {'D', Actions.Down},
            {'J', Actions.Jump},  //A
            {'K', Actions.Jump2},  //2
            {'N', Actions.NoRun},  //No run
            {'G', Actions.BAction},  //B
            {'O', Actions.BAction2},  //1
            {'C', Actions.NunchuckC},  //C
            {'X', Actions.Spinput},  //Spinput
            {'M', Actions.Minus},  //Minus
            {'P', Actions.Plus},  //Plus
            {'H', Actions.Home},  //Home
        });

    public static bool TryParse(char c, out Actions actions) {
        return Chars.TryGetValue(c, out actions);
    }
}